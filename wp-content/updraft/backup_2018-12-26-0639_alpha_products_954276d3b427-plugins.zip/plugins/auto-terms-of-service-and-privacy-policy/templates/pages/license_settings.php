<?php

include __DIR__ . '/settings.php';
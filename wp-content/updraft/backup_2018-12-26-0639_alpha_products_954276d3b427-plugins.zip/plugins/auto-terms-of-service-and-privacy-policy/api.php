<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WPAUTOTERMS_API_URL', 'https://app.wpautoterms.com/' );
define( 'WPAUTOTERMS_PURCHASE_URL', 'https://app.wpautoterms.com/product/v1/buy' );

/*
	|
	|	Only for development purposes
	|	DO NOT MODIFY
	|
*/
//define( 'WPAUTOTERMS_API_URL', 'http://127.0.0.1:5000/' );
//define( 'WPAUTOTERMS_PURCHASE_URL', 'http://127.0.0.1:5000/product/v1/buy' );

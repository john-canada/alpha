<h5 class="item-title">
	<a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a>
</h5>
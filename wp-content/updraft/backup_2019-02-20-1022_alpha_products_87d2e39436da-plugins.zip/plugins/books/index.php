<?php

// silence is golden

<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:19:{s:6:"apiKey";s:160:"810841f0dd5edd51d4d0ccc56ca812d0ef4f53abde05de50cd1720163c90ccb5f6078647a31c297e3bfc3710cc655663b86c2ac5afc1512e3d0166bd9527e1668119e956987552942aafc407d3fb0acf";s:6:"isPaid";b:0;s:7:"siteURL";N;s:7:"homeURL";N;s:14:"whitelistedIPs";N;s:9:"howGetIPs";N;s:25:"howGetIPs_trusted_proxies";N;s:13:"pluginABSPATH";N;s:11:"other_WFNet";b:1;s:9:"serverIPs";N;s:15:"blockCustomText";N;s:13:"timeoffset_wf";N;s:23:"advancedBlockingEnabled";N;s:21:"betaThreatDefenseFeed";N;s:20:"disableWAFIPBlocking";N;s:13:"patternBlocks";N;s:13:"countryBlocks";N;s:11:"otherBlocks";N;s:8:"lockouts";N;}
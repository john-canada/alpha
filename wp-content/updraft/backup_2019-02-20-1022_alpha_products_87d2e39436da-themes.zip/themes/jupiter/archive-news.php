<?php
include('taxonomy-news_category.php');
?>
<h2>Archive-news.php</h2>